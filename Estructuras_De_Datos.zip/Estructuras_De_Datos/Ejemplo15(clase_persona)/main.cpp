#include <Persona.hpp>

int main(int argc, char **argv)
{
	Persona *P1 = new Persona(18);
	Persona *P2 = new Persona(21);
	Persona *P3 = new Persona(78);
	Persona *P4 = new Persona(8);
	Persona *P5 = new Persona(57);
	Persona *P6 = new Persona(32);
	Persona *P7 = new Persona(43);
	Persona *P8 = new Persona(75);
	Persona *P9 = new Persona(16);
	Persona *P10 = new Persona(28);
	
	P1->mostrar();
	P2->mostrar();
	P3->mostrar();
	P4->mostrar();
	P5->mostrar();
	P6->mostrar();
	P7->mostrar();
	P8->mostrar();
	P9->mostrar();
	P10->mostrar();
	
	return 0;
}
