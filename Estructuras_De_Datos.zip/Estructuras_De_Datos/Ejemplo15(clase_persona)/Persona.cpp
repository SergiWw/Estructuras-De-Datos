#include "Persona.hpp"

Persona::Persona(int edad)
{
	//El DNI y el genero se establecen de forma automatica.
	this->edad = edad
}
void Persona::mostrar(){
	cout << "La persona tiene " << this->edad << endl;
	cout << "Edad: " << edad << endl;
    cout << "Genero: " << (genero ? "Mujer" : "Hombre") << endl;
    cout << "DNI: " << dni << endl;
}

Persona::~Persona()
{
}

